copy "%logonserver%\NETLOGON\BER_WINFO.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 /accepteula "%appdata%\BER_WINFO.bgi"

