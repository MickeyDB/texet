@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      ZWO.bat                                                        +
REM + Description: Logon Script ZWO                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   <name> on <date>                                               +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

REM + Function: Map Printers And Network Drives                                   +                                +
rundll32 printui.dll,PrintUIEntry /in /n "\\zwofps02.nwg.wan\ZWOP200"
rundll32 printui.dll,PrintUIEntry /in /n "\\zwofps02.nwg.wan\ZWOP201"
rundll32 printui.dll,PrintUIEntry /in /n "\\zwofps02.nwg.wan\ZWOP205"
rundll32 printui.dll,PrintUIEntry /in /n "\\zwofps02.nwg.wan\ZWOP206"
rundll32 printui.dll,PrintUIEntry /in /n "\\zwofps02.nwg.wan\ZWOP216"


if exist G:\*.* net use G: /d
Net Use G: \\zwofps02.nwg.wan\common /persistent:no
if exist P:\*.* net use P: /d
Net Use P: \\zwofps02.nwg.wan\PROGRAMS /persistent:no
