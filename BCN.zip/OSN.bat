@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      OSN.bat                                                        +
REM + Description: Logon Script OSN                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 15/10/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

REM + Function: Map Printers And Network Drives           

