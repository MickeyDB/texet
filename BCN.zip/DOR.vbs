'   +-----------------------------------------------------------------------------+
'   + Script:      DOR.vbs                                                        +
'   + Description: VBS Script For Connecting Printers And Network Drivers         +
'   + Author:      Remko.oude.elferink@nwg.se                                     +
'   + Company:     New Wave Group                                                 +
'   + Date:        24/01/2012                                                     +
'   + Edited by:   Remko Oude Elferink @ 03/05/2012                               +
'   +-----------------------------------------------------------------------------+

Option Explicit
On Error Resume Next

'   + Create Variable
Dim objNetwork, objSysInfo, strUserPath, objUser, objGroup, strGroup, strGroupName, strGroupPath


Set objNetwork = CreateObject("WScript.Network") 
Set objSysInfo = CreateObject("ADSystemInfo")
strUserPath = "LDAP://" & objSysInfo.UserName
Set objUser = GetObject(strUserPath)

For Each strGroup in objUser.MemberOf
    strGroupPath = "LDAP://" & strGroup
    Set objGroup = GetObject(strGroupPath)
    strGroupName = objGroup.CN

    Select Case strGroupName
        Case "DOR_GG_EVERYONE"
		objNetwork.RemoveNetworkDrive "G:"
		objNetwork.MapNetworkDrive "G:" , "\\nwg.wan\DOR\Data"

		wscript.sleep(10)	
		objNetwork.RemoveNetworkDrive "P:"
		objNetwork.MapNetworkDrive "P:" , "\\nwg.wan\DOR\Programs"
       
    End Select
Next