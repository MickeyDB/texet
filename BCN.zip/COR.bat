@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      COR.bat                                                        +
REM + Description: Logon Script COR                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 23/11/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

REM + Function: Run VBS Script                                                    +
cscript %LOGONSERVER%\SYSVOL\nwg.wan\scripts\COR.vbs