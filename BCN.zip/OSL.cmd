@echo off

@rem Konfig f�r Terminalservrar
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTTSE02 goto WTS
IF %COMPUTERNAME% == GOTTSE03 goto WTS
IF %COMPUTERNAME% == GOTTSE03 goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"


net use s: /d
net use p: /d
net use g: /d
net use g: \\OSLFPS\Common
net use j: /d
net use j: \\GRLFPS01\Common

goto SLUT

:WTS

net use g: /d
net use g: \\OSLFPS\Common


:SLUT