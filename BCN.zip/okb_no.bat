@echo off
IF %COMPUTERNAME% == GOTTSE01 goto TSE
IF %COMPUTERNAME% == STO2KTSE01 goto TSE
IF %COMPUTERNAME% == YTT2KTSE02 goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"

:TSE
net use h: /home
net use g: \\parksrvtemp\felles
net use i: \\OSLDC02\Common
net use j: \\GRLFPS01\Common