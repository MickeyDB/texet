Din.bat
@echo off
IF %COMPUTERNAME% == GOTINF02 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTINF03 goto WTS
IF %COMPUTERNAME% == RDS-FARM goto WTS
IF %COMPUTERNAME% == ADMRDS01 goto WTS
IF %COMPUTERNAME% == ADMRDS02 goto WTS
IF %COMPUTERNAME% == ADMRDS03 goto WTS


copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 /NOLICPROMPT "%appdata%\winfo.bgi"

net use H: /home

net use G: /D
net use G: \\DINFPS01.NWG.WAN\NWM

net use P: /D
net use P: \\DINFPS01.NWG.WAN\Program

goto SLUT


:WTS

net use G: /D
net use G: \\DINFPS01.NWG.WAN\NWM /persistent:no

net use H: /D
net use H: /home /persistent:no

net use I: /D
net use I: \\gotinf01.nwg.wan\public\Corders /persistent:no


:SLUT
