@echo off

IF %COMPUTERNAME% == GOTTSE01 goto TSE

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"

:TSE

net use g: /d
net use g: \\GRLFPS01\Common
net use j: /d
net use j: \\oslfps\Common
net use h: /home
net use p: \\GRLDC01\Programs
net use o: \\GRLFPS01\Marked


:SLUT