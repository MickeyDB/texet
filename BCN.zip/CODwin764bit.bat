@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      COD.bat                                                        +
REM + Description: Logon Script COD                                               +
REM + Author:      Rene.Euverman@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        23/03/2010                                                     +
REM + Edited by:   <name> on <date>                                               +
REM +-----------------------------------------------------------------------------+

REM + check if log on procedure connects to INFOLOG
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTINF02 goto WTS
IF %COMPUTERNAME% == GOTINF03 goto WTS
IF %COMPUTERNAME% == GOTPDM01 goto WTS

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_WINFO.bat

REM + Function: Run VBS Script to delete existing printers                        +
cscript %LOGONSERVER%\SYSVOL\nwg.wan\scripts\RM-Printers.vbs

REM + Function: Map Printers And Network Drives                                   +
REM + Function: Map Printers And Network Drives                                   +

if exist F:\*.* net use F: /d
if exist G:\*.* net use G: /d
Net Use G: \\codfps02.nwg.wan\COMMON/persistent:no
if exist H:\*.* net use H: /d
if exist I:\*.* net use I: /d
if exist L:\*.* net use L: /d
if exist P:\*.* net use P: /d
Net Use P: \\codfps02.nwg.wan\PROGRAMS /persistent:no
if exist R:\*.* net use R: /d
if exist X:\*.* net use X: /d
if exist Y:\*.* net use Y: /d
Net Use Y: \\codfps02.nwg.wan\Spedizioni /persistent:no


:WTS

:END