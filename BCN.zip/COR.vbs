
'   +-----------------------------------------------------------------------------+
'   + Script:      COR.vbs                                                        +
'   + Description: VBS Script For Connecting Printers And Network Drivers         +
'   + Author:      Dries.Deflem@nwg.se                                            +
'   + Company:     New Wave Group                                                 +
'   + Date:        09/02/2010                                                     +
'   + Edited by:   Dries Deflem on 16/11/2012                                     +
'   +-----------------------------------------------------------------------------+

Option Explicit
On Error Resume Next

Dim objNetwork, objSysInfo, strUserPath, objUser, objGroup, strGroup, strGroupName, strGroupPath
Dim CORP001, CORP002, CORP003, CORP004, CORP005, CORP006, CORP007, CORP008, CORP009, CORP010

CORP001 = "\\corfps02.nwg.wan\CORP001"
CORP002 = "\\corfps02.nwg.wan\CORP002"
CORP003 = "\\corfps02.nwg.wan\CORP003"
CORP004 = "\\corfps02.nwg.wan\CORP004"
CORP005 = "\\corfps02.nwg.wan\CORP005"
CORP006 = "\\corfps02.nwg.wan\CORP006"
CORP007 = "\\corfps02.nwg.wan\CORP007"
CORP008 = "\\corfps02.nwg.wan\CORP008"
CORP009 = "\\corfps02.nwg.wan\CORP009"
CORP010 = "\\corfps02.nwg.wan\CORP010"

objNetwork.AddWindowsPrinterConnection "\\alan\Epson."


Set objNetwork = CreateObject("WScript.Network") 
Set objSysInfo = CreateObject("ADSystemInfo")
strUserPath = "LDAP://" & objSysInfo.UserName
Set objUser = GetObject(strUserPath)

For Each strGroup in objUser.MemberOf
    strGroupPath = "LDAP://" & strGroup
    Set objGroup = GetObject(strGroupPath)
    strGroupName = objGroup.CN

    Select Case strGroupName
        Case "COR_GG_EVERYONE"
		objNetwork.RemoveNetworkDrive "P:"
		objNetwork.MapNetworkDrive "P:" , "\\corfps02.nwg.wan\PROGRAMS"	
		objNetwork.RemoveNetworkDrive "T:"
		objNetwork.MapNetworkDrive "T:" , "\\corfps02.nwg.wan\DATA"	
		objNetwork.AddWindowsPrinterConnection CORP001
		objNetwork.AddWindowsPrinterConnection CORP002
		objNetwork.AddWindowsPrinterConnection CORP003		
		objNetwork.AddWindowsPrinterConnection CORP004		
		objNetwork.AddWindowsPrinterConnection CORP005		
		objNetwork.AddWindowsPrinterConnection CORP006
		objNetwork.AddWindowsPrinterConnection CORP007			
		objNetwork.AddWindowsPrinterConnection CORP008		
		objNetwork.AddWindowsPrinterConnection CORP009			
		objNetwork.AddWindowsPrinterConnection CORP010
        Case "COR_GG_HR"
		objNetwork.RemoveNetworkDrive "L:"
		objNetwork.MapNetworkDrive "L:" , "\\corfps02.nwg.wan\HR$"
        Case "COR_GG_EVERYONE_CRAFT"
		objNetwork.RemoveNetworkDrive "S:"
		objNetwork.MapNetworkDrive "S:" , "\\corfps02.nwg.wan\DATACRAFT"
        Case "COR_GG_FINANCE"
		objNetwork.RemoveNetworkDrive "X:"
		objNetwork.MapNetworkDrive "X:" , "\\corfps02.nwg.wan\Financial$"
    End Select
Next