@echo off

@rem Konfig f�r Terminalservrar
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTTSE02 goto WTS
IF %COMPUTERNAME% == GOTTSE03 goto WTS
IF %COMPUTERNAME% == GOTTSE03 goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"


net use g: /d
net use g: \\OREDC01\Common
net use h: /d
net use h: /HOME
net use p: /d
net use p: \\OREDC01\Program
net use t: /d
net use t: \\OREDC01\Finance

goto SLUT

:WTS

net use g: /d
net use g: \\OREDC01\Common
net use h: /d
net use h: /HOME

:SLUT
