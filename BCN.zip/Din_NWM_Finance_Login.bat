Din.bat
@echo off
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 /NOLICPROMPT "%appdata%\winfo.bgi"


net use G: /D
net use G: \\DINFPS01.NWG.WAN\NWM

net use P: /D
net use P: \\DINFPS01.NWG.WAN\Program

net use S: /D
net use S: "\\DINFPS01.NWG.WAN\Common Finance"

net use T: /D
net use T: "\\DINFPS01.NWG.WAN\NWM Finance"

goto SLUT


:WTS

net use G: /D
net use G: DINFPS01.NWG.WAN\DJ /persistent:no

net use H: /D
net use H: /home /persistent:no

:SLUT
