@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      BER.bat                                                        +
REM + Description: Logon Script BER                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 02/12/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\BER_WINFO.bat

REM + Function: Run VBS Script                                                    +
cscript %LOGONSERVER%\SYSVOL\nwg.wan\scripts\BERwin764bit.VBS

REM + Function: copy DBS shortcut 
xcopy "\\berfps01\Data\DBS.url" "%userprofile%\Desktop\" /C /H /R /Y /Z
