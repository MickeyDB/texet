@echo off

IF %COMPUTERNAME% == GOTTSE01 goto TSE
IF %COMPUTERNAME% == GOTTSE02 goto TSE
IF %COMPUTERNAME% == INFOLOG goto TSE
IF %COMPUTERNAME% == INFOFRNT goto TSE

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"

if exist G:\*.* net use G: /d
if exist P:\*.* net use P: /d
if exist Q:\*.* net use Q: /d

REM NET USE H: /home /persistent:no
NET USE G: \\UPLFPS01\Jobman /persistent:no
NET USE P: \\UPLFPS01\Program /persistent:no
NET USE Q: \\superoffice\So_Docs /persistent:no

goto END

:TSE
if exist G:\*.* net use G: /d
if exist P:\*.* net use P: /d

NET USE G: \\UPLFPS01\Jobman /persitent:no
NET USE P: \\UPLFPS01\Program /persitent:no

goto END

:END