@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      LYO.bat                                                        +
REM + Description: Logon Script LYO                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        27/02/2014                                                     +
REM + Edited by:   Rene Euverman on 27/02/2014                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

REM + Function: Map Printers And Network Drives                                   +

if exist G:\*.* net use G: /d
Net Use G: \\lyofps01.nwg.wan\DATA /persistent:no
if exist P:\*.* net use P: /d
Net Use P: \\lyofps01.nwg.wan\Programs /persistent:no