@echo off

@rem Konfig f�r Terminalservrar
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTTSE02 goto WTS
IF %COMPUTERNAME% == GOTTSE03 goto WTS
IF %COMPUTERNAME% == GOTTSE04 goto WTS
IF %COMPUTERNAME% == INFOLOG goto WTS
IF %COMPUTERNAME% == RDS-FARM goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /accepteula /timer=0 "%appdata%\winfo.bgi"

net use g: /d
net use g: \\SKAFPS01\Common
net use h: /d
net use h: /HOME
net use p: /d
net use p: \\SKAFPS01\Program
net use j: /d
net use j: \\skaapp01\Prodintegration

goto END

:WTS

net use g: /d
net use g: \\SKAFPS01\Common
net use h: /d
net use h: /HOME

:END