@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      MIJ.bat                                                        +
REM + Description: Logon Script MIJ                                               +
REM + Author:      Ren� Euverman                                                  +
REM + Company:     New Wave Group                                                 +
REM + Date:        25/04/2011                                                     +
REM + Edited by:   Dries Deflem on 8/12/2010                                      +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

REM + Function: Map Printers And Network Drives                                   +

if exist I:\*.* net use I: /d
Net Use I: \\mijfps01.nwg.wan\DATA /persistent:no