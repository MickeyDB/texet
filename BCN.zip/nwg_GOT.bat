@echo off

@rem Konfig f�r Terminalservrar
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTTSE02 goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /NOLICPROMPT /timer=0 "%appdata%\winfo.bgi"

net use h: /home
net use G: /d
net use G: \\nwg.wan\got-common\NWG
net use p: /d
net use p: \\nwg.wan\got-programs\NWG

goto SLUT

:WTS

net use g: /d
net use g: \\GOTFPS01\nwg /persistent:no

net use h: /home /persistent:no

net use I: /D
net use I: \\gotinf01.nwg.wan\public\Corders /persistent:no

:SLUT