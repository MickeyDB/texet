@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      MIJ.bat                                                        +
REM + Description: Logon Script MIJ                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 04/05/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Run VBS Script                                                   +
cscript %LOGONSERVER%\SYSVOL\nwg.wan\scripts\MIJ.vbs

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

