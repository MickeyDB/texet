@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      PAR.bat                                                        +
REM + Description: Logon Script PAR                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        2012-09-18                                                     +
REM + Edited by:   Dries Deflem                                                   +
REM +-----------------------------------------------------------------------------+

if exist F:\*.* net use F: /d
Net Use F: \\berfps02.nwg.wan\COMMONFR$ /persistent:no
if exist G:\*.* net use G: /d
Net Use G: \\aarfps03.nwg.wan\salesadminfrance$ /persistent:no

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat