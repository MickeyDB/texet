@echo off

IF %COMPUTERNAME% == INFOFRNT goto TSE
IF %COMPUTERNAME% == GOTTSE01 goto TSE
IF %COMPUTERNAME% == GOTTSE02 goto TSE
IF %COMPUTERNAME% == INFOLOG goto TSE

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"

net use h: /D
NET USE G: /D
NET USE P: /D

net use h: /home 
NET USE G: \\UPLFPS01\Texet /persistent:yes
NET USE P: \\UPLFPS01\Program /persistent:yes
 
goto SLUT

:TSE

if exist G:\*.* net use G: /d
if exist P:\*.* net use P: /d

NET USE G: \\UPLFPS01\Texet /persistent:yes
NET USE P: \\UPLFPS01\Program /persistent:yes


:SLUT