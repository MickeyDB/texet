@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      DOR.bat                                                        +
REM + Description: Logon Script BCN                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        24/01/2012                                                     +
REM + Edited by:   Remko Oude Elferink on 03/05/2012                              +
REM +-----------------------------------------------------------------------------+

REM + Function: Run VBS Script                                                   +
cscript %LOGONSERVER%\SYSVOL\nwg.wan\scripts\DOR.vbs

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

