@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      OBE.bat                                                        +
REM + Description: Logon Script OBE                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 29/10/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

REM + Function: Map Printers And Network Drives                                   +

if exist G:\*.* net use G: /d
Net Use G: \\OBEFPS02\DATA /persistent:no
if exist P:\*.* net use P: /d
Net Use P: \\OBEFPS02\PROGRAMS /persistent:no