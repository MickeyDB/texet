@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      BER.bat                                                        +
REM + Description: Logon Script BER                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 02/12/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Run VBS Script                                                    +
cscript %LOGONSERVER%\SYSVOL\nwg.wan\scripts\BER2.vbs


