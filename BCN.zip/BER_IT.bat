@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      BER_IT.bat                                                     +
REM + Description: Logon Script BER                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 22/10/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_WINFO.bat

REM + Function: Run VBS Script                                                    +
cscript %LOGONSERVER%\SYSVOL\nwg.wan\scripts\BER.vbs

