Din.bat
@echo off
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 /NOLICPROMPT "%appdata%\winfo.bgi"

net use H: /home

net use G: /D
net use G: \\DINFPS01.NWG.WAN\Projob

net use P: /D
net use P: \\DINFPS01.NWG.WAN\Program


goto SLUT


:WTS

net use G: /D
net use G: DINFPS01.NWG.WAN\Projob /persistent:no

net use H: /D
net use H: /home /persistent:no


:SLUT
