@echo off

@rem Konfig f�r Terminalservrar
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTTSE02 goto WTS


copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /NOLICPROMPT /timer=0 "%appdata%\winfo.bgi"

net use g: /d
net use g: \\HULFPS\Common
net use h: /home
net use m: /d
net use m: \\HULFPS\marketing
net use p: /d
net use p: \\HULFPS\program
net use s: /d
net use s: \\HULFPS\scan

:WTS
net use g: \\HULFPS\Common /persistent:no
net use h: /home /persistent:no
net use m: \\hulfps\marketing /persistent:no
