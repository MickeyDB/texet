@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      MIJ.bat                                                        +
REM + Description: Logon Script MIJ                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 8/12/2010                                      +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

REM + Function: Map Printers And Network Drives                                   +


if exist I:\*.* net use I: /d
Net Use I: \\mijfps02.nwg.wan\DATA /persistent:no