@echo off

@rem Konfig f�r Terminalservrar
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTTSE02 goto WTS
IF %COMPUTERNAME% == GOTTSE03 goto WTS
IF %COMPUTERNAME% == GOTTSE04 goto WTS
IF %COMPUTERNAME% == INFOLOG goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /accepteula /timer=0 "%appdata%\winfo.bgi"

REM + Function: Map Printers And Network Drives                                   +
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap001
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap002
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap003
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap004
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap005
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap006
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap007
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap008
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap009
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap009_inv
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap010
rundll32 printui.dll,PrintUIEntry /in /n \\skafps01.nwg.wan\skap011

net use g: /d
net use g: \\SKAFPS01\Common
net use h: /d
net use h: /HOME
net use p: /d
net use p: \\SKAFPS01\Program

goto END

:WTS

net use g: /d
net use g: \\SKAFPS01\Common
net use h: /d
net use h: /HOME

:END