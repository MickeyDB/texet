@echo off

@rem Konfig f�r Terminalservrar
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"

net use g: /d
net use p: /d
net use p: \\borfps\program
net use g: \\borfps\common
net use j: /d
net use j: \\galdc01\gemensam

goto END

:WTS
net use p: \\borfps\program /persistent:no
net use g: \\borfps\common /persistent:no
net use h: /home /persistent:no
net use j: /d
net use j: \\galdc01\gemensam /persistent:no

:END