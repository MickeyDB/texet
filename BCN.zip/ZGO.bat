@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      ZGO.bat                                                        +
REM + Description: Logon Script ZGO                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 16/12/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\BER_WINFO.bat


REM + Function: Map Printers And Network Drives                                   +
rundll32 printui.dll,PrintUIEntry /in /n "\\zgofps02.nwg.wan\zgop001"
rundll32 printui.dll,PrintUIEntry /in /n "\\zgofps02.nwg.wan\zgop002"
rundll32 printui.dll,PrintUIEntry /in /n "\\zgofps02.nwg.wan\zgop003"
rundll32 printui.dll,PrintUIEntry /in /n "\\zgofps02.nwg.wan\zgop004"
rundll32 printui.dll,PrintUIEntry /in /n "\\zgofps02.nwg.wan\zgop005"
rundll32 printui.dll,PrintUIEntry /in /n "\\zgofps02.nwg.wan\zgop202"
rundll32 printui.dll,PrintUIEntry /in /n "\\zgofps02.nwg.wan\zgop203"

if exist G:\*.* net use G: /d
Net Use G: \\zgofps02.nwg.wan\DATA /persistent:no
if exist P:\*.* net use P: /d
Net Use P: \\zgofps02.nwg.wan\PROGRAMS /persistent:no
if exist S:\*.* net use P: /d
Net Use S: \\berfps01.nwg.wan\Artwork /persistent:no

gpupdate /force