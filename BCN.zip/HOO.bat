@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      HOO.bat                                                        +
REM + Description: Logon Script HOO                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 04/11/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\BER_WINFO.bat

REM + Function: Map Printers And Network Drives                                   +

if exist G:\*.* net use G: /d
Net Use G: \\berfps01.nwg.wan\DataHoo /persistent:no
if exist P:\*.* net use P: /d
Net Use P: \\berfps01.nwg.wan\PROGRAMS /persistent:no
if exist S:\*.* net use S: /d
Net Use S: \\berfps01.nwg.wan\Workdisk /persistent:no
if exist R:\*.* net use R: /d
Net Use R: \\berfps01.nwg.wan\Artwork /persistent:no
