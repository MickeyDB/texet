@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      DGN.bat                                                        +
REM + Description: Logon Script DGN                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        2014-01-28                                                     +
REM + Edited by:                                                                  +
REM +-----------------------------------------------------------------------------+

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_WINFO.bat

if exist G:\*.* net use G: /d
Net Use G: \\zwofps02.nwg.wan\common /persistent:no
if exist P:\*.* net use P: /d
Net Use P: \\zwofps02.nwg.wan\PROGRAMS /persistent:no

