' BRO_MAP_DRIVES.vbs
' VBScript to map network drives.
' Editor:	Lars Gattbro, Calle Sch�tt
' Version 1.0 - 2010-05-18
' Version 1.1 - 2013-05-27
' ------------------------------------------------------' 
Option Explicit
Dim strUserName, strDriveLetter1, strDriveLetter2, strDriveLetter3, strRemotePath1, strRemotePath2, strRemotePath3
Dim objNetwork, objShell 
Dim CheckDrive, AlreadyConnected, intDrive 

strDriveLetter1 = "H:" 
strDriveLetter2 = "G:" 
strDriveLetter3 = "M:" 
strRemotePath1 = "\\BROFPS02\USERS$" 
strRemotePath2 = "\\nwg.wan\bro\Common" 
strRemotePath3 = "\\nwg.wan\bro\Marketing"

Set objShell = CreateObject("WScript.Shell") 
Set objNetwork = WScript.CreateObject("WScript.Network") 
Set CheckDrive = objNetwork.EnumNetworkDrives() 

strUserName = objNetwork.UserName 

On Error Resume Next
AlreadyConnected = False 
For intDrive = 0 To CheckDrive.Count - 1 Step 2 
If CheckDrive.Item(intDrive) =strDriveLetter1 _
Then AlreadyConnected =True
Next 

objNetwork.RemoveNetworkDrive strDriveLetter1 
objNetwork.MapNetworkDrive strDriveLetter1, strRemotePath1 _
& "\" & strUserName 
objNetwork.RemoveNetworkDrive strDriveLetter2 
objNetwork.MapNetworkDrive strDriveLetter2, strRemotePath2
objNetwork.RemoveNetworkDrive strDriveLetter3 
objNetwork.MapNetworkDrive strDriveLetter3, strRemotePath3

Wscript.Quit
