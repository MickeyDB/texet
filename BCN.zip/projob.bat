@rem Konfig f�r Terminalservrar

IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == YTT2KTSE02 goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"

:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"

:WTS
net use h: /home
net use g: \\din2k3sql01\Projob

:SLUT

