@echo off

REM +-----------------------------------------------------------------------------+
REM + Script:      ERL.bat                                                        +
REM + Description: Logon Script ERL                                               +
REM + Author:      Dries.Deflem@nwg.se                                            +
REM + Company:     New Wave Group                                                 +
REM + Date:        09/02/2010                                                     +
REM + Edited by:   Dries Deflem on 18/10/2010                                     +
REM +-----------------------------------------------------------------------------+

REM + check if log on procedure connects to INFOLOG
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS
IF %COMPUTERNAME% == GOTINF02 goto WTS

REM + Function: Set Background Information                                        +
call %LOGONSERVER%\SYSVOL\nwg.wan\scripts\ADM_NWGEUR_WINFO.bat

REM + Function: Map Printers And Network Drives                                   +

if exist G:\*.* net use G: /d
Net Use G: \\erlfps02.nwg.wan\DATA /persistent:no
if exist P:\*.* net use P: /d
Net Use P: \\erlfps02.nwg.wan\PROGRAMS /persistent:no
GOTO END

:WTS

:END