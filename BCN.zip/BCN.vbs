'   +-----------------------------------------------------------------------------+
'   + Script:      BCN.vbs                                                        +
'   + Description: VBS Script For Connecting Printers And Network Drivers         +
'   + Author:      erik.paauw@nwg.se                                     +
'   + Company:     New Wave Group                                                 +
'   + Date:        24/01/2012                                                     +
'   + Edited by:   Erik Paauw                              +
'   +-----------------------------------------------------------------------------+

Option Explicit
On Error Resume Next

'   + Create Variable
Dim objNetwork, objSysInfo, strUserPath, objUser, objGroup, strGroup, strGroupName, strGroupPath



Set objNetwork = CreateObject("WScript.Network") 
Set objSysInfo = CreateObject("ADSystemInfo")
strUserPath = "LDAP://" & objSysInfo.UserName
Set objUser = GetObject(strUserPath)

For Each strGroup in objUser.MemberOf
    strGroupPath = "LDAP://" & strGroup
    Set objGroup = GetObject(strGroupPath)
    strGroupName = objGroup.CN

    Select Case strGroupName
        Case "BCN_GG_EVERYONE"
		objNetwork.RemoveNetworkDrive "G:"
		objNetwork.MapNetworkDrive "G:" , "\\bcnfps02.nwg.wan\Data"

			
		objNetwork.RemoveNetworkDrive "H:"
		objNetwork.MapNetworkDrive "H:" , "\\bcnfps02.nwg.wan\Programs\TipsaCli"
			
		objNetwork.RemoveNetworkDrive "P:"
		objNetwork.MapNetworkDrive "P:" , "\\bcnfps02.nwg.wan\Programs"
	
		objNetwork.RemoveNetworkDrive "Y:"
		objNetwork.MapNetworkDrive "Y:" , "\\EMIL.NWG.WAN\Integration\Shippers"
	
       
    End Select
Next