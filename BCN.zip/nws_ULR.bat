@echo off

@rem Konfig f�r Terminalservrar
IF %COMPUTERNAME% == GOTTSE01 goto WTS
IF %COMPUTERNAME% == INFOFRNT goto WTS

copy "%logonserver%\NETLOGON\winfo.bgi" "%appdata%" /Y
IF EXIST "%appdata%\Bginfo.exe" GOTO INFO
copy "%logonserver%\NETLOGON\Bginfo.exe" "%appdata%"


:INFO
"%appdata%\bginfo.exe" /timer=0 "%appdata%\winfo.bgi"

net use i: /d
net use p: /d
net use g: /d

net use p: \\nwg.wan\ulr\programs
net use i: \\borfps\common
net use g: \\nwg.wan\ulr\common

goto SLUT

:WTS
net use p: \\nwg.wan\ulr\programs /persistent:no
net use i: \\borfps\common /persistent:no
net use g: \\nwg.wan\ulr\common /persistent:no
net use h: /home /persistent:no

:SLUT